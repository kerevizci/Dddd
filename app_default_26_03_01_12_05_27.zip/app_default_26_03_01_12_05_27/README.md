# Hamster Clicker: Cheese Empire 🐹🧀

A fully-featured mobile idle clicker game built with React Native and Expo. Experience the journey of a hamster building a cheese dynasty!

## 🚀 Features
- **Core Mechanics**: Tap the central hamster to earn cheese. Build idle production with a crew of diverse hamsters.
- **Hamster Management**: Collect Common, Rare, Epic, and Legendary hamsters, each with unique production stats.
- **Progression System**: Scale your empire with upgrades that multiply your tapping power and idle efficiency.
- **Prestige/Rebirth**: Reset your progress for permanent multipliers when your empire reaches legendary status.
- **Mobile Optimized**: High-performance "squash and stretch" animations using Reanimated and Moti.
- **Persistent Progress**: Your cheese and hamsters are automatically saved using AsyncStorage.

## 🛠️ Prerequisites
- Node.js (v18 or newer recommended)
- Expo Go app on your iOS/Android device (for previewing)
- npm or yarn

## 📦 Installation
1. Install dependencies:
    `npm install`

2. Start the development server:
    `npm start`

3. Scan the QR code:
    Open the Expo Go app on your phone and scan the QR code displayed in your terminal.

## 🕹️ How to Play
1. **Tap**: Click on the central hamster to generate Cheese.
2. **Hire**: Use your Cheese to hire more hamsters in the shop menu.
3. **Upgrade**: Purchase upgrades like "Sharp Teeth" or "Golden Wheel" to increase your efficiency.
4. **Scale**: Watch your Cheese Per Second (CPS) grow as you unlock rarer hamsters.
5. **Prestige**: Once you reach 1,000,000 total cheese, look for the prestige option to restart with massive permanent bonuses.

## 🏗️ Project Structure
- `src/store/useGameStore.js`: The brain of the game, managing all state and logic.
- `src/components/HUD.js`: The top display showing total cheese and production rates.
- `src/components/HamsterSprite.js`: The animated tapping unit.
- `src/components/UpgradeList.js`: The shop and recruitment interface.
- `App.js`: Entry point managing the main layout and game loop.

## 🔧 Troubleshooting
- **Animations lagging?** Ensure you are running on a physical device for the best Reanimated performance.
- **State didn't save?** Ensure you are not clearing your app data or local storage.
- **Images not loading?** Check your internet connection as assets are served from Unsplash CDN.
