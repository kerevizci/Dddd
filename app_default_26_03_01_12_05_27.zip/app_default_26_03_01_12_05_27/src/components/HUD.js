import React from 'react';
import { View, Text, StyleSheet, SafeAreaView } from 'react-native';
import { useGameStore } from '../store/useGameStore';
import { Coins, Zap, Trophy } from 'lucide-react-native';

export const HUD = () => {
  const cheese = useGameStore((state) => state.cheese);
  const cps = useGameStore((state) => state.calculateCPS());
  const prestigeMultiplier = useGameStore((state) => state.prestigeMultiplier);

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.container}>
        <View style={styles.statBox}>
          <Coins color="#FFD700" size={24} />
          <View>
            <Text style={styles.label}>Cheese</Text>
            <Text style={styles.value}>{Math.floor(cheese).toLocaleString()}</Text>
          </View>
        </View>

        <View style={styles.statBox}>
          <Zap color="#00C8FF" size={24} />
          <View>
            <Text style={styles.label}>CPS</Text>
            <Text style={styles.value}>{cps.toFixed(1)}/s</Text>
          </View>
        </View>

        <View style={styles.statBox}>
          <Trophy color="#FF4D4D" size={24} />
          <View>
            <Text style={styles.label}>Multi</Text>
            <Text style={styles.value}>x{prestigeMultiplier.toFixed(1)}</Text>
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: {
    backgroundColor: '#FFF9E6',
  },
  container: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    padding: 15,
    backgroundColor: '#FFF',
    borderBottomWidth: 2,
    borderBottomColor: '#F0E6D2',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  statBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  label: {
    fontSize: 10,
    color: '#888',
    fontWeight: 'bold',
    textTransform: 'uppercase',
  },
  value: {
    fontSize: 16,
    fontWeight: '900',
    color: '#444',
  },
});
