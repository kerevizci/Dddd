import React from 'react';
import { Pressable, StyleSheet, Image } from 'react-native';
import { MotiView } from 'moti';
import { useGameStore } from '../store/useGameStore';

export const HamsterSprite = () => {
  const performTap = useGameStore((state) => state.performTap);

  return (
    <Pressable onPress={performTap} style={styles.container}>
      <MotiView
        from={{ scale: 1 }}
        animate={{ scale: 1 }}
        transition={{ type: 'spring' }}
        state={{
            scale: 1,
        }}
        key="main-hamster"
      >
        <MotiView
            from={{ translateY: 0 }}
            animate={{ translateY: -10 }}
            transition={{
                loop: true,
                type: 'timing',
                duration: 1500,
                reverse: true
            }}
        >
            <Image 
                source={{ uri: 'https://images.unsplash.com/photo-1548767797-d8c844163c4c?w=400' }}
                style={styles.image}
            />
        </MotiView>
      </MotiView>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  container: {
    justifyContent: 'center',
    alignItems: 'center',
    height: 300,
    width: '100%',
  },
  image: {
    width: 220,
    height: 220,
    borderRadius: 110,
    borderWidth: 8,
    borderColor: '#FFD700',
  },
});
