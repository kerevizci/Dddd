import React from 'react';
import { ScrollView, View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { useGameStore } from '../store/useGameStore';
import { ShoppingCart, ArrowUpCircle } from 'lucide-react-native';

export const UpgradeList = () => {
  const { hamsters, cheese, buyHamster, buyUpgrade, upgrades, unlockedUpgrades } = useGameStore();

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.sectionTitle}>Hamster Crew</Text>
      {hamsters.map((hamster) => (
        <TouchableOpacity 
          key={hamster.id} 
          style={[styles.item, cheese < hamster.cost && styles.disabled]}
          onPress={() => buyHamster(hamster.id)}
          disabled={cheese < hamster.cost}
        >
          <Image source={{ uri: hamster.image }} style={styles.avatar} />
          <View style={styles.info}>
            <Text style={styles.name}>{hamster.name} ({hamster.count})</Text>
            <Text style={styles.desc}>Produces {hamster.baseProduction} cheese/s</Text>
          </View>
          <View style={styles.priceTag}>
            <Text style={styles.priceText}>{hamster.cost}</Text>
          </View>
        </TouchableOpacity>
      ))}

      <Text style={styles.sectionTitle}>Upgrades</Text>
      {upgrades.map((upgrade) => {
        const purchased = unlockedUpgrades.includes(upgrade.id);
        return (
          <TouchableOpacity 
            key={upgrade.id} 
            style={[
                styles.item, 
                (cheese < upgrade.cost || purchased) && styles.disabled,
                purchased && styles.purchased
            ]}
            onPress={() => buyUpgrade(upgrade.id)}
            disabled={cheese < upgrade.cost || purchased}
          >
            <ArrowUpCircle color={purchased ? "#4CAF50" : "#2196F3"} size={32} />
            <View style={styles.info}>
              <Text style={styles.name}>{upgrade.name}</Text>
              <Text style={styles.desc}>{upgrade.description}</Text>
            </View>
            <View style={styles.priceTag}>
              <Text style={styles.priceText}>{purchased ? 'OWNED' : upgrade.cost}</Text>
            </View>
          </TouchableOpacity>
        );
      })}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9F4EA',
  },
  content: {
    padding: 16,
    paddingBottom: 100,
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: '900',
    color: '#5C4033',
    marginVertical: 15,
  },
  item: {
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 12,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
    borderWidth: 2,
    borderColor: '#E8DFCC',
  },
  disabled: {
    opacity: 0.6,
  },
  purchased: {
    borderColor: '#4CAF50',
    backgroundColor: '#F1F8E9',
  },
  avatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
  },
  info: {
    flex: 1,
    marginLeft: 12,
  },
  name: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  desc: {
    fontSize: 12,
    color: '#666',
  },
  priceTag: {
    backgroundColor: '#FFE082',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  priceText: {
    fontWeight: 'bold',
    fontSize: 14,
    color: '#795548',
  },
});
