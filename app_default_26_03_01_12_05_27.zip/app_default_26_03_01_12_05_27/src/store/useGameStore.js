import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';

const INITIAL_HAMSTERS = [
  { id: 'h1', name: 'Baby Hammy', type: 'common', level: 1, baseProduction: 1, count: 1, cost: 10, image: 'https://images.unsplash.com/photo-1548767797-d8c844163c4c?w=200' },
  { id: 'h2', name: 'Chef Hamster', type: 'rare', level: 1, baseProduction: 5, count: 0, cost: 100, image: 'https://images.unsplash.com/photo-1544436400-98327263595e?w=200' },
  { id: 'h3', name: 'Scientist Ham', type: 'epic', level: 1, baseProduction: 25, count: 0, cost: 1000, image: 'https://images.unsplash.com/photo-1541806447238-e060ef6bbbe6?w=200' },
  { id: 'h4', name: 'King Cheddar', type: 'legendary', level: 1, baseProduction: 150, count: 0, cost: 10000, image: 'https://images.unsplash.com/photo-1502673530728-f79b4cab31b1?w=200' },
];

const UPGRADES = [
  { id: 'u1', name: 'Sharp Teeth', description: 'Double tap power', cost: 50, type: 'tap', multiplier: 2 },
  { id: 'u2', name: 'Better Bedding', description: '+20% Idle Production', cost: 200, type: 'idle', multiplier: 1.2 },
  { id: 'u3', name: 'Golden Wheel', description: 'Triple tap power', cost: 1000, type: 'tap', multiplier: 3 },
];

export const useGameStore = create(
  persist(
    (set, get) => ({
      cheese: 0,
      gems: 10,
      totalCheeseEarned: 0,
      tapPower: 1,
      prestigeMultiplier: 1,
      hamsters: INITIAL_HAMSTERS,
      upgrades: UPGRADES,
      unlockedUpgrades: [],
      lastSave: Date.now(),

      // Core Actions
      addCheese: (amount) => set((state) => ({ 
        cheese: state.cheese + amount,
        totalCheeseEarned: state.totalCheeseEarned + amount 
      })),

      performTap: () => {
        const { tapPower, prestigeMultiplier } = get();
        const amount = tapPower * prestigeMultiplier;
        get().addCheese(amount);
      },

      buyHamster: (hamsterId) => set((state) => {
        const hamster = state.hamsters.find(h => h.id === hamsterId);
        if (state.cheese >= hamster.cost) {
          return {
            cheese: state.cheese - hamster.cost,
            hamsters: state.hamsters.map(h => 
              h.id === hamsterId ? { ...h, count: h.count + 1, cost: Math.floor(h.cost * 1.5) } : h
            )
          };
        }
        return state;
      }),

      buyUpgrade: (upgradeId) => set((state) => {
        const upgrade = state.upgrades.find(u => u.id === upgradeId);
        if (state.cheese >= upgrade.cost && !state.unlockedUpgrades.includes(upgradeId)) {
          let newTapPower = state.tapPower;
          if (upgrade.type === 'tap') newTapPower *= upgrade.multiplier;
          
          return {
            cheese: state.cheese - upgrade.cost,
            tapPower: newTapPower,
            unlockedUpgrades: [...state.unlockedUpgrades, upgradeId]
          };
        }
        return state;
      }),

      calculateCPS: () => {
        const { hamsters, unlockedUpgrades, upgrades, prestigeMultiplier } = get();
        let baseCPS = hamsters.reduce((acc, h) => acc + (h.baseProduction * h.count), 0);
        
        // Apply idle multipliers
        unlockedUpgrades.forEach(id => {
          const upgrade = upgrades.find(u => u.id === id);
          if (upgrade.type === 'idle') baseCPS *= upgrade.multiplier;
        });

        return baseCPS * prestigeMultiplier;
      },

      prestige: () => set((state) => {
        const bonus = Math.floor(Math.sqrt(state.totalCheeseEarned / 1000000));
        if (bonus < 1) return state; // Need at least 1M cheese to prestige
        
        return {
          cheese: 0,
          hamsters: INITIAL_HAMSTERS,
          unlockedUpgrades: [],
          tapPower: 1,
          prestigeMultiplier: state.prestigeMultiplier + (bonus * 0.1),
          totalCheeseEarned: 0
        };
      }),

      processIdle: () => {
        const cps = get().calculateCPS();
        if (cps > 0) {
          get().addCheese(cps / 10); // Running at 10 ticks per second
        }
      }
    }),
    {
      name: 'hamster-storage',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);
