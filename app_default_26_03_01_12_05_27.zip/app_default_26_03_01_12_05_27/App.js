import React, { useEffect } from 'react';
import { View, StyleSheet, ImageBackground } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { HUD } from './src/components/HUD';
import { HamsterSprite } from './src/components/HamsterSprite';
import { UpgradeList } from './src/components/UpgradeList';
import { useGameStore } from './src/store/useGameStore';

export default function App() {
  const processIdle = useGameStore((state) => state.processIdle);

  useEffect(() => {
    // Game Loop: Process idle production every 100ms
    const interval = setInterval(() => {
      processIdle();
    }, 100);

    return () => clearInterval(interval);
  }, [processIdle]);

  return (
    <View style={styles.container}>
      <StatusBar style="dark" />
      <HUD />
      
      <ImageBackground 
        source={{ uri: 'https://images.unsplash.com/photo-1518531933037-91b2f5f229cc?w=800' }}
        style={styles.gameArea}
        imageStyle={{ opacity: 0.2 }}
      >
        <HamsterSprite />
      </ImageBackground>

      <View style={styles.shopArea}>
        <UpgradeList />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF',
  },
  gameArea: {
    height: 350,
    backgroundColor: '#FFEEAD',
    justifyContent: 'center',
  },
  shopArea: {
    flex: 1,
  },
});
